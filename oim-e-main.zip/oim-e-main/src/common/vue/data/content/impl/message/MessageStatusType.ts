enum MessageStatusType {
    sending,
    succeed,
    fail,
}

export default MessageStatusType;

