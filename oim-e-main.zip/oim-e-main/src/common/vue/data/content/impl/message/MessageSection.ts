export default class MessageSection {

}
