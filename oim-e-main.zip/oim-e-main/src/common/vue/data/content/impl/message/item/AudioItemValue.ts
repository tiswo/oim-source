import FileItemValue from '@/common/vue/data/content/impl/message/item/FileItemValue';

export default class AudioItemValue extends FileItemValue {

}
