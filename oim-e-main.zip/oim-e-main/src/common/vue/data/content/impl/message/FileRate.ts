export class FileRate {

    public static operationUpload: number = 0;
    public static operationDownload: number = 1;

    public operation: number = 0;
    public rateShow: boolean = false;
    public rate: number = 1;
}
