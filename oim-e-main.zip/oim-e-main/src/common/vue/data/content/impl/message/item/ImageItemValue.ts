import FileItemValue from '@/common/vue/data/content/impl/message/item/FileItemValue';

export default class ImageItemValue extends FileItemValue {

}
