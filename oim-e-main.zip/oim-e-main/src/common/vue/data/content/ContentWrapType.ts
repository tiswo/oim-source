enum ContentWrapType {

    message = 0,
    prompt = 1,
}

export default ContentWrapType;
