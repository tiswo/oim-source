import AbstractInitializerBox from '@/app/base/initialize/AbstractInitializerBox';
import BaseInitializer from '@/app/base/initialize/BaseInitializer';

export default class EnterInitializerBox extends AbstractInitializerBox<BaseInitializer> {


}
