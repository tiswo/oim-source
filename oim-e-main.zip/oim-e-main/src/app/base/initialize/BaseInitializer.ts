export default interface BaseInitializer {

    initialize(): void;

    getOrder(): number;
}
