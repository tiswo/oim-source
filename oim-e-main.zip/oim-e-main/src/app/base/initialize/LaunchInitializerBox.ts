import LaunchInitializer from '@/app/base/initialize/LaunchInitializer';
import AbstractInitializerBox from '@/app/base/initialize/AbstractInitializerBox';

export default class LaunchInitializerBox extends AbstractInitializerBox<LaunchInitializer> {

}
