export default interface DataPrompt {

    prompt(data: any): void;

}
