export default class ContentInfo {
    /**
     * 信息编码
     */
    public code: string = '';
    /**
     * 信息内容
     */
    public text: string = '';
}
