export default interface ErrorPrompt {
    prompt(message: string): void;
}
