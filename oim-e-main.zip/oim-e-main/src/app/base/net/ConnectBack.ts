export default interface ConnectBack {

    onOpen(): void;

    onError(): void;
}
