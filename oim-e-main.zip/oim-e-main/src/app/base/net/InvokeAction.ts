export default interface InvokeAction {

    invoke(key: string, data: any): void;
}
