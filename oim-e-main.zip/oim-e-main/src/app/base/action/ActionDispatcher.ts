export default class ActionDispatcher {

    public putAction(): void {
        // no
    }
}
