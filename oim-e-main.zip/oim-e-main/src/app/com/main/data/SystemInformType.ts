export default class SystemInformType {

    public static TYPE_APPLY_HANDLE = 'apply_handle';

}
