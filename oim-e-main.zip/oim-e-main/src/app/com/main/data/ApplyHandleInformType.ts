export default class ApplyHandleInformType {
    public static GroupInviteApply = 'GroupInviteApply';
    public static GroupInviteeApply = 'GroupInviteeApply';
    public static GroupJoinApply = 'GroupJoinApply';
    public static ContactAddApply = 'ContactAddApply';

}
