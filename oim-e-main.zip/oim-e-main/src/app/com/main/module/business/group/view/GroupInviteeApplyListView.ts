import VisibleView from '@/app/com/client/common/view/VisibleView';

export default interface GroupInviteeApplyListView extends VisibleView {

}
