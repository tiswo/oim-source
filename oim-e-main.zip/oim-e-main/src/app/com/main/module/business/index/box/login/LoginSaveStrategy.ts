interface LoginSaveStrategy {

}
