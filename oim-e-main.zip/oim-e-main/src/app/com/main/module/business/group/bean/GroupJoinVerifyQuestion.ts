export default class GroupJoinVerifyQuestion {
    public id: string = '';
    public groupId: string = '';
    public question: string = '';
}
