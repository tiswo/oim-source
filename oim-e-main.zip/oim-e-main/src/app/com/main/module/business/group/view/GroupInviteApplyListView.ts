import VisibleView from '@/app/com/client/common/view/VisibleView';

export default interface GroupInviteApplyListView extends VisibleView {

}
