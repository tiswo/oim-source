export default class GroupInviteApplyQuery {

    public verifyHandleType: string = '';
}
