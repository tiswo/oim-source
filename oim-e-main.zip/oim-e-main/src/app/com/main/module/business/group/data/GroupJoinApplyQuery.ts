export default class GroupJoinApplyQuery {

    public handleType: string = '';
}
