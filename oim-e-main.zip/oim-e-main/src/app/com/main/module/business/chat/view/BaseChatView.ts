import View from '@/app/com/client/common/view/View';
import VisibleView from '@/app/com/client/common/view/VisibleView';

interface BaseChatView extends VisibleView {

}
