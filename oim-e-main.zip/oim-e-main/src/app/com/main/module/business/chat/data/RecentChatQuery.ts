export default class RecentChatQuery {

}
