class UserChatUnread {
    public receiveUserId: string = '';
    public sendUserId: string = '';
    public lastContentId: string = '';
    public unreadCount: number = 0;
    public timestamp: number = 0;
}

export default UserChatUnread;
