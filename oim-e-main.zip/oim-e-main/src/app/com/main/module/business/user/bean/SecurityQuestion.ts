export default class SecurityQuestion {
    public id: string = '';
    public question: string = '';
    public answer: string = '';
}
