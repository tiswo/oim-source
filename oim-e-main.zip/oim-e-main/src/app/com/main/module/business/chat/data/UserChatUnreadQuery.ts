class UserChatUnreadQuery {
    public receiveUserId: string = '';
    public sendUserId: string = '';
}

export default UserChatUnreadQuery;
