import AbstractMessageUnreadBox from '@/app/com/client/module/information/box/unread/AbstractMessageUnreadBox';

export default class SystemMessageUnreadBox extends AbstractMessageUnreadBox {

}
