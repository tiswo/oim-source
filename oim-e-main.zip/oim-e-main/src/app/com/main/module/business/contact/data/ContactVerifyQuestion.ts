export default class ContactVerifyQuestion {
    public id: string = '';
    public question: string = '';
}
