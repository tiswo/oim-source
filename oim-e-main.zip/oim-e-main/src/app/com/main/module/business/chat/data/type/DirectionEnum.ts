enum DirectionEnum {
    /**
     * 之前
     */
    before = 'before',
    /**
     * 之后
     */
    after = 'after',
}

export default DirectionEnum;
