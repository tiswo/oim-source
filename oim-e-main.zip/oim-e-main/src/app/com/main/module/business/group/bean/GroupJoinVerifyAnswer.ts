export default class GroupJoinVerifyAnswer {
    public questionId: string = '';
    public question: string = '';
    public answer: string = '';
}
