import AbstractMaterial from '@/app/base/context/AbstractMaterial';

export default class GroupBusinessAction extends AbstractMaterial {

    private static action: string = '1.3.005';

}

