import AbstractMessageUnreadBox from '@/app/com/client/module/information/box/unread/AbstractMessageUnreadBox';

export default class UserMessageUnreadBox extends AbstractMessageUnreadBox {


}
