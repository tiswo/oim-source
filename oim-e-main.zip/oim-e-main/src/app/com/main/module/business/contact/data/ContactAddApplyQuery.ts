export default class ContactAddApplyQuery {

    public handleType: string = '';
}
