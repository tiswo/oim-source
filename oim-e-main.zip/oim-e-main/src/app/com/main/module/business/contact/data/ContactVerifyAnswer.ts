export default class ContactVerifyAnswer {
    public questionId: string = '';
    public question: string = '';
    public answer: string = '';
}
