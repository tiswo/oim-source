export default class GroupQuery {
    public name: string = '';
    public queryText: string = '';
}
