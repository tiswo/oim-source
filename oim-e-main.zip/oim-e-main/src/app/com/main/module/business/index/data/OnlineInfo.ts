export default class OnlineInfo {
    public client: object = {};
    public location: string = '';
    public netAddress: string = '';
    public onlineTimestamp: number = 0;
    public currentOffline: boolean = false;
}
