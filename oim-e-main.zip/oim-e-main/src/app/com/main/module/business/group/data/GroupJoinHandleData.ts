export default class GroupJoinHandleData {
    public applyIds: string[] = []; // 请求记录id
    public handleUserId: string = '';
    public handleType: string = '';
    public message: string = '';
}
