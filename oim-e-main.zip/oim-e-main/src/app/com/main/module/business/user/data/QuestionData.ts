import SecurityQuestion from '@/app/com/main/module/business/user/bean/SecurityQuestion';

export default class QuestionData {
    public questions: SecurityQuestion[] = [];
}
