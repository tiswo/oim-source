export default class ContactRelation {
    public id: string = '';
    public ownerUserId: string = '';
    public categoryId: string = '';
    public contactUserId: string = '';
    public remark: string = '';
}
