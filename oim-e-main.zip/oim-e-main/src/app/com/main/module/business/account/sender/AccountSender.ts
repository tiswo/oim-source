import AbstractSender from '@/app/com/main/common/base/sender/AbstractSender';

export default class PersonalSender extends AbstractSender {

    private action: string = '1.1.001';

}
