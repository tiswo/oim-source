export default class GroupInviteeApplyQuery {
    public inviteeHandleType: string = '';
}
