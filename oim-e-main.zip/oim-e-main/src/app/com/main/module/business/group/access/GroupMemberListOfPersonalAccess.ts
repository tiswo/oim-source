import AbstractMaterial from '@/app/base/context/AbstractMaterial';

export default class GroupMemberListOfPersonalAccess extends AbstractMaterial {

}
