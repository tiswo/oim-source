export default class GroupRelation {
    public id: string = '';
    public userId: string = '';
    public categoryId: string = '';
    public groupId: string = '';
    public remark: string = '';
}
