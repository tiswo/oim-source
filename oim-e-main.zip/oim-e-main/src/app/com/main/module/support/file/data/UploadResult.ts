export default class UploadResult {
    public key: string = '';
    public file: File | null = null;
    public result: any;
}
