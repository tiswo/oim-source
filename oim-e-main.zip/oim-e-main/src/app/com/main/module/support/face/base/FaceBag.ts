import FaceCategory from '@/app/com/main/module/support/face/data/FaceCategory';

export default interface FaceBag {

    getFaceCategory(): FaceCategory;
}
