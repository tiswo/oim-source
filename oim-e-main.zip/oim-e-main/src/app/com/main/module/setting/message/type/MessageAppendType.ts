enum MessageAppendType {
    /**
     * 上次位置
     */
    last = 0,
    /**
     * 总是最下面
     */
    bottom = 1,

}

export default MessageAppendType;
