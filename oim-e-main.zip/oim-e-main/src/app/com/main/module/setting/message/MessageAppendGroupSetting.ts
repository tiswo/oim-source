import MessageDisplaySetting from '@/app/com/main/module/setting/message/MessageDisplaySetting';

class MessageAppendGroupSetting extends MessageDisplaySetting {

}

export default MessageAppendGroupSetting;

