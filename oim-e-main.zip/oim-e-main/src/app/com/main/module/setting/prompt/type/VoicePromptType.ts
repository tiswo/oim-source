enum VoicePromptType {
    /**
     * 未读提示
     */
    unread = 0,
    /**
     * 总是提示
     */
    always = 1,
    /**
     * 不提示
     */
        never = 2,

}

export default VoicePromptType;
