import VoicePromptSetting from '@/app/com/main/module/setting/prompt/VoicePromptSetting';

export default class VoicePromptGroupSetting extends VoicePromptSetting {


}



