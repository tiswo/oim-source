export default interface View {

}
