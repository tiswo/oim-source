export default class UnreadInfo {
    public key: string = '';
    public unreadCount: number = 0;
}
