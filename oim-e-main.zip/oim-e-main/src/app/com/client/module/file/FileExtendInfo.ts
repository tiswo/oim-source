import FileProgressInfo from '@/app/com/client/module/file/FileProgressInfo';

export default class FileExtendInfo {

    public progressInfo: FileProgressInfo = new FileProgressInfo();
}
