export default class FileProgressInfo {

    public show: boolean = false;
    public working: boolean = false;
    public percentage: number = 0;
    public speedText: string = '';
}
