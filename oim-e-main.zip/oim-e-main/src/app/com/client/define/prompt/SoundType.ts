enum SoundType {
    System = 1,
    Message = 2,
    Notice = 3,
}

export default SoundType;
