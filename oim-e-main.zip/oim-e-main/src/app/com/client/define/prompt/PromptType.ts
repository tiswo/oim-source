enum PromptType {
    info = 'info',
    success = 'success',
    warn = 'warn',
    error = 'error',
}

export default PromptType;
