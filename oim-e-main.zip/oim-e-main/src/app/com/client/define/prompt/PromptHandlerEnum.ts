enum PromptHandlerEnum {
    PromptHandler = 'PromptHandler',
}

export default PromptHandlerEnum;
