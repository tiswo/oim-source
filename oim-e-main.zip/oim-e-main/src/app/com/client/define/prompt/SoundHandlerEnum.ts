enum SoundHandlerEnum {
    SoundHandler = 'SoundHandler',
}

export default SoundHandlerEnum;
