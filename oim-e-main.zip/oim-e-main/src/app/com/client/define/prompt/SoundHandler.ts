export default interface SoundHandler {

    play(type: number): void;

}
