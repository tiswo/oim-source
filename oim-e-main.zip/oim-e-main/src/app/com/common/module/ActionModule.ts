import AbstractMaterial from '@/app/base/context/AbstractMaterial';

export default class ActionModule extends AbstractMaterial {


}
