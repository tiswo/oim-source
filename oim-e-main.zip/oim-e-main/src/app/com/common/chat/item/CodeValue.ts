export default class PositionValue {
    public language: string = '';
    public content: string = '';
}
