export default class UrlValue {
    public name: string = '';
    public value: string = '';
}
