export default class AtValue {

    public userId: string = '';
    public text: string = '';
}
