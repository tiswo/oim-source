export default class FaceValue {
    public categoryId: string = '';
    public key: string = '';
    public text: string = '';
    public path: string = '';
    public height: number | undefined;
    public width: number | undefined;
}
