export default class PositionValue {
    public name: string = '';
    public address: string = '';
    public longitude: number = 0.0;
    public latitude: number = 0.0;
}
