import FileValue from '@/app/com/common/chat/item/FileValue';

export default class VideoValue extends FileValue {

}
