export default class BaseValue {
    public keyword: string = '';
}
