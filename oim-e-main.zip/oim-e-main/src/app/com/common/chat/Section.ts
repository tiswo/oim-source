import Item from '@/app/com/common/chat/Item';


export default class Section {
    /**
     * 段落中可能是有图片、文件、文本等信息混排
     */
    public items: Item[] = [];
}
