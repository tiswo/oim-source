export default class Font {
    public underline: boolean = false;
    public bold: boolean = false;
    public italic: boolean = false;
    public color: string = '000000';
    public name: string = '微软雅黑';
    public size: number = 12;
}
