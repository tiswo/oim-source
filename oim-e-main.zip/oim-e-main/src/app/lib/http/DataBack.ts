export default interface DataBack {
    back(data: object): void;
}
