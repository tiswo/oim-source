import DownloadTool from '@/app/lib/download/DownloadTool';

export default class DownloadToolUtil {
    public static tool: DownloadTool = new DownloadTool();
}
