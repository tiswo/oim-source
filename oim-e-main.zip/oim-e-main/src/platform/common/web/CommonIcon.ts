export default class CommonIcon {

    public static noLogo: string = 'assets/general/common/logo/no/no.png';
    public static noUser: string = 'assets/general/common/images/common/no/no-user.png';
}
