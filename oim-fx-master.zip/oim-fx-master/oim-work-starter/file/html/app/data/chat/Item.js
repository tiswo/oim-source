class Item {
    type = '';
    value = '';
    data = {};
}
