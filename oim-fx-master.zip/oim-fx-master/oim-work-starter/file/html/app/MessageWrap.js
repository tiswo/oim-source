class MessageWrap {
    type = 1;

    setType(type) {
        this.type = type;
    }

    getType() {
        return this.type;
    }
}
