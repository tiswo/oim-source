package com.oimchat.client.general.kernel.work.module.group.data.query;

/**
 * 群邀请查询<br>
 * Date 2019-06-13 08:47:27<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class GroupInviteApplyQuery {

}
