
package com.oimchat.client.general.kernel.work.module.group.observer.listener;

/**
 * Description <br>
 * Date 2021-03-30 16:48:28<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public interface GroupCategoryEventListener {

	void updateSort();

}
