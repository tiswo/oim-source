
package com.oimchat.app.fx.view.base.control;

import javafx.scene.control.ListView;

/**
 * Description <br>
 * Date 2020-07-07 15:48:43<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class CoverListView<T> extends ListView<T> {

}
