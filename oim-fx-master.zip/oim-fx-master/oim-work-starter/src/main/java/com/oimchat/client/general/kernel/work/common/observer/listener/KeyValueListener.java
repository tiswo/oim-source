
package com.oimchat.client.general.kernel.work.common.observer.listener;

/**
 * Description <br>
 * Date 2021-03-14 16:48:33<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public interface KeyValueListener<K, V> {

	void value(K key, V value);
}
