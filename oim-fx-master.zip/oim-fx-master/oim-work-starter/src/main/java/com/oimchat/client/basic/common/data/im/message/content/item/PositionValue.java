package com.oimchat.client.basic.common.data.im.message.content.item;

/**
 * @author XiaHui
 * @date 2017-11-04 3:17:28
 */
public class PositionValue {

	private String name;
	private String address;
	private double longitude;
	private double latitude;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

}
