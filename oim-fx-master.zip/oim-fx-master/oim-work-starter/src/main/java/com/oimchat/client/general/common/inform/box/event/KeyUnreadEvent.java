
package com.oimchat.client.general.common.inform.box.event;

/**
 * Description <br>
 * Date 2021-03-26 15:27:18<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public interface KeyUnreadEvent<K> {

	void event(K key, long count);
}
