package com.oimchat.client.general.kernel.work.module.group.entity;
/**
 * @author: XiaHui
 * @date: 2018-04-22 09:57:47
 */
public class GroupNotice {

}
