
package com.oimchat.client.general.common.inform.listener;

/**
 * Description 
 * <br>
 * Date 2021-03-29 21:54:08<br>
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class SoundListener {

}
