package com.oimchat.client.common.event;

/**
 * Description <br>
 * Date 2020-03-12 17:28:03<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public interface GetBasicAction<T> {

	public T get();
}
