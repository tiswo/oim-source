
package com.oimchat.app.fx.view.common.util;

/**
 * Description <br>
 * Date 2021-03-04 20:33:50<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class WebViewHandler {

}
