
package com.oimchat.app.fx.view.base.control;

import javafx.scene.control.Button;

/**
 * Description <br>
 * Date 2020-07-07 15:33:58<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class CoverButtonPrimary extends Button {

}
