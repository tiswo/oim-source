package com.oimchat.client.basic.common.data.im.message.content.item;

/**
 * @author XiaHui
 * @date 2017-05-29 7:34:48
 */
public class AtValue {

	private String userId;
	private String text;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
