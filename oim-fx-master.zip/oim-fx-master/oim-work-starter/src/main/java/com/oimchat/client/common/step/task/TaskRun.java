
package com.oimchat.client.common.step.task;

/**
 * Description <br>
 * Date 2021-03-31 00:52:23<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public interface TaskRun {

	void run(TaskNext n);
}
