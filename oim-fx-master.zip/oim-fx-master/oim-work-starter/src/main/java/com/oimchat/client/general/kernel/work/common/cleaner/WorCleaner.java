
package com.oimchat.client.general.kernel.work.common.cleaner;

/**
 * Description <br>
 * Date 2021-03-27 21:48:21<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public interface WorCleaner {

	void clear();

	// void revise();
}
