
package com.oimchat.app.fx.net;

/**
 * Description 
 * <br>
 * Date 2021-04-16 10:35:12<br>
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class ImageAsyn {

}
