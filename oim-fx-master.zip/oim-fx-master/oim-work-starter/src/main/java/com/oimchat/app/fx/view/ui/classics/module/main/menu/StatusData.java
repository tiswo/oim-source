
package com.oimchat.app.fx.view.ui.classics.module.main.menu;

/**
 * Description 
 * <br>
 * Date 2021-03-10 15:46:55<br>
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class StatusData {

	
}
