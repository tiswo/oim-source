
package com.oimchat.app.fx.base.component.web;

/**
 * Description 
 * <br>
 * Date 2021-02-26 17:59:17<br>
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class WebViewInitialize {

}
