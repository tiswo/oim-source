
package com.oimchat.app.fx.view.ui.classics.module.login;

import javafx.scene.control.Button;

/**
 * Description <br>
 * Date 2020-07-07 15:57:41<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class LoginButton extends Button {

}
