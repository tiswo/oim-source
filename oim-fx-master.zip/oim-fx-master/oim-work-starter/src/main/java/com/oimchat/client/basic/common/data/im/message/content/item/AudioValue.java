package com.oimchat.client.basic.common.data.im.message.content.item;

/**
 * @author XiaHui
 * @date 2017-05-29 7:34:48
 */
public class AudioValue extends FileValue{

}
