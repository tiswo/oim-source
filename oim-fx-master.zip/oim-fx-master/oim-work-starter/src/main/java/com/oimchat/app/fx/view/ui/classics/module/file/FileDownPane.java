package com.oimchat.app.fx.view.ui.classics.module.file;
/**
 * @author XiaHui
 * @date 2017年5月27日 下午6:59:09
 */
public class FileDownPane {

}
