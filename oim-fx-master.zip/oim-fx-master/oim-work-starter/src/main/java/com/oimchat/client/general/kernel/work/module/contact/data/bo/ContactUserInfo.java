
package com.oimchat.client.general.kernel.work.module.contact.data.bo;

import com.oimchat.client.general.kernel.work.module.contact.entity.ContactRelation;

/**
 * Description 
 * <br>
 * Date 2021-03-16 15:39:56<br>
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class ContactUserInfo {

	ContactRelation relation;
}
