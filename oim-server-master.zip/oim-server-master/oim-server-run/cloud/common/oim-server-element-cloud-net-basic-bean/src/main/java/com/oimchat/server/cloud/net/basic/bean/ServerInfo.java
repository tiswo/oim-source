package com.oimchat.server.cloud.net.basic.bean;

/**
 * 2018-03-01 10:58:32<br>
 * 
 * @author: XiaHui
 */
public class ServerInfo {

	private String id;

	public ServerInfo() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
