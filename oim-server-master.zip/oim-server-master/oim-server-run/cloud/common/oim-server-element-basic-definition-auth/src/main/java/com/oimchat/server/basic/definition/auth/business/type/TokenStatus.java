package com.oimchat.server.basic.definition.auth.business.type;

/**
 * Description <br>
 * Date 2021-01-19 10:41:46<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public enum TokenStatus {

	/**
	 * 
	 */
	none,
	/**
	 * 
	 */
	available,
	/**
	 * 
	 */
	expired
}
