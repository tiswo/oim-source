package com.oimchat.server.run.cloud.net.producer.impl.mq.user;

/**
 * Description <br>
 * Date 2020-05-13 18:01:22<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class UserQueueRoutingKey {

	public static String ROUTING_KEY = "oim.server.base.user.change";

}
