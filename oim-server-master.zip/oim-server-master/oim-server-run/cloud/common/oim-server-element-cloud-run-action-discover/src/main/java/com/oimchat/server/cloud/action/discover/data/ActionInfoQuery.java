package com.oimchat.server.cloud.action.discover.data;

/**
 * Description 
 * <br>
 * Date 2021-01-13 09:08:36<br>
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class ActionInfoQuery {

}
