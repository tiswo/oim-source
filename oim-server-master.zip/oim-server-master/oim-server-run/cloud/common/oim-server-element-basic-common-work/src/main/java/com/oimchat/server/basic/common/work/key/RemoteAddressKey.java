package com.oimchat.server.basic.common.work.key;

/**
 * Description <br>
 * Date 2020-05-19 15:39:00<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class RemoteAddressKey {

	public static String USER_REMOTE_ADDRESS_KEY = "UserRemoteAddress";
}
