package com.globalegrow.fas.gateway.auth.service;

/**
 *  
 * <br>
 * Date 2019-08-19 18:12:48<br>
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */
public class AddressAuthServiceTest {

}
