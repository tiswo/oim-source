package com.oimchat.server.general.kernel.core.gateway.common.route;

/**
 * Description <br>
 * Date 2020-05-16 21:18:23<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class AuthConstant {

	public static final String TOKEN = "token";
	public static final String KEY = "key";
}
