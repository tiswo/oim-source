package com.oimchat.server.general.kernel.core.gateway.common.route;

/**
 * 
 * <br>
 * Date 2019-12-03 16:17:57<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class DataConstant {

	/**
	 * 消息主体
	 */
	public static String BODY = "body";

	/**
	 * 消息头部
	 */
	public static String HEAD = "head";

}
