package com.globalegrow.fas.gateway;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * 
 * 
 * <br>
 * Date 2019-08-09 17:12:58<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class GatewayApplicationTest {

	@Test
	public void contextLoads() {
	}

}
