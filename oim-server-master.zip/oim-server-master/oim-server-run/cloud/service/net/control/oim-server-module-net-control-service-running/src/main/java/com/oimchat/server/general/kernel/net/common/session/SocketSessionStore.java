package com.oimchat.server.general.kernel.net.common.session;

/**
 * Description <br>
 * Date 2019-07-06 16:35:15<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public interface SocketSessionStore {

	boolean has(String key);
}
