
package com.oimchat.server.general.kernel.net.module.system.service;

/**
 * Description <br>
 * Date 2020-04-13 23:26:34<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class SocketSessionService {

	public void offline(String userId, String offlineTag, String onlineId) {

	}
}
