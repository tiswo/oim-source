package com.oimchat.server.general.common.api.inside.system.setting.bean;

/**
 * Description <br>
 * Date 2020-05-18 12:10:45<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public class MultipleCheck {

	boolean multiple;

	public boolean isMultiple() {
		return multiple;
	}

	public void setMultiple(boolean multiple) {
		this.multiple = multiple;
	}
}
