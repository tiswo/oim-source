package com.oimchat.server.general.kernel.work.module.business.contact.service;

import org.springframework.stereotype.Service;

/**
 * Date 2019-01-20 13:11:09<br>
 * Description
 * 
 * @author XiaHui<br>
 * @since 1.0.0
 */
@Service
public class ContactService {

}
