package com.oimchat.server.general.kernel.work.module.business.contact.action;

import org.springframework.stereotype.Component;

import com.onlyxiahui.framework.action.dispatcher.annotation.ActionMapping;

/**
 * Description <br>
 * Date 2021-03-31 09:55:43<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */
@Component
@ActionMapping(value = "1.2.005")
public class ContactMemberAction {

}
