package com.oimchat.server.general.kernel.work.module.base.contact.dao;

import org.springframework.stereotype.Repository;

import com.onlyxiahui.aware.basic.dao.BaseDAO;

/**
 * 
 * Date 2019-01-20 11:35:07<br>
 * Description 联系人DAO
 * 
 * @author XiaHui<br>
 * @since 1.0.0
 */
@Repository
public class ContactDAO extends BaseDAO {

}
