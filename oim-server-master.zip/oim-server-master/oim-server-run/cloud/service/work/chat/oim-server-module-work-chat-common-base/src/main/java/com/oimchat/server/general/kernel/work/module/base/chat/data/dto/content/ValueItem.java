package com.oimchat.server.general.kernel.work.module.base.chat.data.dto.content;

/**
 * Date 2019-01-06 11:58:43<br>
 * Description
 * 
 * @author XiaHui<br>
 * @since 1.0.0
 */

public class ValueItem {

	private String key;
	private Object value;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}
}
