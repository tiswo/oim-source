package com.oimchat.server.general.kernel.work.module.base.chat.box;

/**
 * Date 2019-02-11 18:30:31<br>
 * Description 群禁言信息
 * @author XiaHui<br>
 * @since 1.0.0
 */

public interface GroupBanBox {

}
