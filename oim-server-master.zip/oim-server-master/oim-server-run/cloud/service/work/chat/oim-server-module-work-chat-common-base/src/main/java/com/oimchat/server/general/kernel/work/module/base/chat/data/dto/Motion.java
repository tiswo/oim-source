package com.oimchat.server.general.kernel.work.module.base.chat.data.dto;

/**
 * Date 2019-03-07 22:01:54<br>
 * Description
 * 
 * @author XiaHui<br>
 * @since 1.0.0
 */

public class Motion {

	private String type;
	private String data;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

}
