
package com.oimchat.server.general.kernel.work.define.user.function;

/**
 * Description <br>
 * Date 2020-04-09 19:12:16<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public interface UserInitialize {

	void initialize(String userId);
}
