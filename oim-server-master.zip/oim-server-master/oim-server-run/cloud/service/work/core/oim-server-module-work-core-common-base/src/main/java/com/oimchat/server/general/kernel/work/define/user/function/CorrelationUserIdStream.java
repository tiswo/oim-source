package com.oimchat.server.general.kernel.work.define.user.function;

import java.util.List;

/**
 * Description <br>
 * Date 2020-11-03 09:28:03<br>
 * 
 * @author XiaHui [onlovexiahui@qq.com]<br>
 * @since 1.0.0
 */

public interface CorrelationUserIdStream {

	void list(List<String> userIds);
}
