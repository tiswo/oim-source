package com.oimchat.server.general.kernel.support.file.module.common.dao;

import org.springframework.stereotype.Repository;

import com.onlyxiahui.aware.basic.dao.BaseDAO;

/**
 * 描述：
 * @author XiaHui 
 * @date 2015年12月30日 下午8:39:32
 * @version 0.0.1
 */
@Repository
public class FileDataDAO extends BaseDAO{

}
